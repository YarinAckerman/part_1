package part_1;

public class Truck extends Vehicle {
	
	//Yarin Ackerman 318666443
	//Rami Abu Rabia 314820135

	public Truck(VehicleWasher vv) {
		
		super(vv);
	}

	
	public String toString() {
		
		return "Truck";
	}
}
