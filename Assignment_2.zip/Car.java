package part_1;

public class Car extends Vehicle {
	
	//Yarin Ackerman 318666443
	//Rami Abu Rabia 314820135

	public Car(VehicleWasher vv) {
		super(vv);
	}

	public String toString() {
		
		return "Car";
	}
	
}
