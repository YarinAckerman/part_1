package part_1;

public class SUV extends Vehicle {
	
	//Yarin Ackerman 318666443
	//Rami Abu Rabia 314820135

	public SUV(VehicleWasher vv) {
		super(vv);
	}

	
	
	public String toString() {
		
		return "SUV";
	}
	
}
